This folder contains an example page for the Boilerplate template. To create your own website pages, simply copy this folder and rename to your desired page/site node. 

IMPORTANT: Use ONLY root-relative links in HTML files (omit the leading / from these links). If you have moved your site to a new directory, update the <base> tag in the HTML pages to reflect the new root location
